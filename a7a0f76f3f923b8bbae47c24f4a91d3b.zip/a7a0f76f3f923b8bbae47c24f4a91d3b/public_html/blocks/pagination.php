<nav class="pagination">
        <ul class="pagination__list">
            <li class="pagination__list-item"><a href="news1.php" class="start">&lt;</a></li>
            <li class="pagination__list-item"><a href="news1.php">1</a></li>
            <li class="pagination__list-item"><a href="news2.php">2</a></li>
            <li class="pagination__list-item"><a href="news3.php">3</a></li>
            <li class="pagination__list-item"><a href="#">4</a></li>
            <li class="pagination__list-item"><a href="#">5</a></li>
            <li class="pagination__list-item"><a href="#">6</a></li>
            <li class="pagination__list-item"><a href="#" class="end">&gt;</a></li>
        </ul>
</nav>