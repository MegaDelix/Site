    <nav class="pagination">
        <ul class="pagination__list">
            <li class="pagination__list-item">
                <a href="blog.php" class="start">&lt;</a>
            </li>
            <li class="pagination__list-item"><a href="blog.php">1</a></li>
            <li class="pagination__list-item"><a href="#">2</a></li>
            <li class="pagination__list-item"><a href="#">3</a></li>
            <li class="pagination__list-item"><a href="#">4</a></li>
            <li class="pagination__list-item"><a href="#">5</a></li>
            <li class="pagination__list-item"><a href="#">6</a></li>
            <li class="pagination__list-item">
                <a href="#" class="end">&gt;</a>
            </li>
        </ul>
    </nav>