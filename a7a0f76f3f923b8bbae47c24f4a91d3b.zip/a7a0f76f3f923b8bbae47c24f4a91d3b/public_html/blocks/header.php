<section class="header_stil">
  <header class="header">
    <a href="index.php">Blogs Finder</a>
    <nav>
      <ul class="header">
          <li><a href="blog.php">News</a></li>
          <?php
            if($_COOKIE['user'] == ''):
          ?>
          <li><a href="login.php">Войти</a></li>
          <li><a href="registration.php">Регистрация</a></li>
          <?php else: ?>
          <li><a href="favorite.php" style="padding: 10px 20px; background-color: #ff6600; 
          color: #fff; text-decoration: none; border-radius: 5px;">Избранное</a></li>
          <li style="background-color: #66B2FF; padding: 5px 15px; 
          border-radius: 10px;"><?=$_COOKIE['user']?></li>
          <li><a href="logout.php">Выйти</a></li>
          <?php endif;?>
      </ul>
    </nav>
</header>