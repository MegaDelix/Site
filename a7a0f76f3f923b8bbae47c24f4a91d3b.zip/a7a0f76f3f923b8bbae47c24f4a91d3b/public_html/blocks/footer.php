<footer>
<footer class="container pt-4 my-md-5 pt-md-5 border-top">
    <div class="row">
      <div class="col-6 col-md">
        <h5>Поддержка</h5>
        <ul class="list-unstyled text-small">
          <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Создать обращение</a></li>
          <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Онлайн чат</a></li>
          <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Частые вопросы</a></li>
        </ul>
      </div>
      <div class="col-6 col-md">
        <h5>О компании</h5>
        <ul class="list-unstyled text-small">
          <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Местонахождение</a></li>
          <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Правила</a></li>
        </ul>
      </div>
    </div>
  </footer>