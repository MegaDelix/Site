<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, inital-scale=1.0">
    <link rel="stylesheet" href="css/Вёрстка%20списка%20элементов.css">
    <link href="css/Вёрстка%20детальной%20страницы.css" type="text/css" rel="stylesheet"> <!-- Перенесите эту строку внутрь тега <head> -->
    <title>ТЗ</title>
</head>
<body>
<?php require "blocks/header.php"; ?>

<div class="news__card">
    <?php
    $mysqli = new mysqli('localhost', 'c95301sd_users', 'Pass1234', 'c95301sd_users');

    // Указание необходимго blog_id
    $blog_id = 1;

    $result = $mysqli->prepare("SELECT title, date_time, image_name, content FROM news WHERE id = ?");
    $result->bind_param("i", $blog_id);
    $result->execute();
    $result->store_result();

    if ($result->num_rows > 0) {
        $result->bind_result($title, $date_time, $image_name, $content);
        $result->fetch();
        
        echo '<h2>' . $title . '</h2>';
        echo '<span>' . date('d.m.y H:i:s', strtotime($date_time)) . '</span>';
        echo '<div class="news__card-wrapper">';
        echo '<div class="news__card-img">';
        echo '<img src="./img/' . $image_name . '.png" alt="ddd" />';
        echo '</div>';
        echo '<div class="news__card-descr">';
        echo '<p>' . $content . '</p>';
        echo '</div>';
        echo '</div>';
    } else {
        echo 'No data found';
    }

    $result->close();

    if($_COOKIE['user'] == ''): ?>
        <form class="news__card-comment">
            <span>Вам нужно <a href="login.php" class="login-btn">войти</a>, чтобы оставить комментарий</span>
        </form>
    <?php else: ?>
        <form class="news__card-comment" method="POST" action="comments.php">
          <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
          <span>Оставить комментарий</span>
          <label for="comment"></label>
          <textarea name="comment" id="comment" cols="30" rows="10" required></textarea>
          <button type="submit">Отправить комментарий</button>
        </form>
    <?php endif; ?>

    <ul class="comments">
      <?php
         $comments_query = "SELECT users.login, comments.date_time, comments.content 
                      FROM comments 
                      JOIN users ON comments.user_id = users.id 
                      WHERE comments.blog_id = ? 
                      ORDER BY comments.date_time DESC";

         $result = $mysqli->prepare($comments_query);
         $result->bind_param("i", $blog_id);
         $result->execute();
         $result->store_result();
    
         if ($result->num_rows > 0) {
             $result->bind_result($login, $date_time, $content);
             while ($result->fetch()) {
                 echo '<li class="comments-item">';
                 echo '  <div class="comment-author">';
                 echo '    <h3>'.$login.'</h3>';
                 echo '    <span>'.date('d.m.y H:i:s', strtotime($date_time)).'</span>';
                 echo '  </div>';
                 echo '  <p>'.$content.'</p>';
                 echo '</li>';
             }
         } else {
             echo 'Нет комментариев для данного блога.';
             echo '<img src="img/pusto.gif" alt="Пусто" width="300" height="69"/>';
         }
    
         $result->close();
         ?>
    </ul>
   <?php require "blocks/pagination.php" ?>
    
</div>

</body>
<?php require "blocks/footer.php" ?>
</html>