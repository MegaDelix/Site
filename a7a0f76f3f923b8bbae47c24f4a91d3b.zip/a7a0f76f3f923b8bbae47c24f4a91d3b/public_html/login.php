<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, inital-scale=1.0">
<title>Вход</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>
<style>
.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

    .header ul {
        display: flex;
        list-style: none;
        margin: 10px 10px 10px 0;
        padding: 0;
    }

    .header li {
        margin-left: 10px;
    }

    .header nav {
        margin-left: auto;
    }
    .header a {
        color: black;
        font-size: 15px;
        font-weight: bold;
        text-decoration: none;
    }

    .header li:nth-child(2) a {
        background-color: #66B2FF;
        color: white;
        padding: 5px 15px;
        border-radius: 10px;
        text-decoration: none;
    }

    .header li:nth-child(3) a {
        color: #66B2FF;
        padding: 5px 15px;
        border: 2px solid #66B2FF;
        border-radius: 10px;
        text-decoration: none;
    }
</style>
<?php require "blocks/header.php" ?>
<div class="form_container">
    <form action="auth.php" method="post">
        <label for="email">email:</label><br>
        <input type="text" id="email" name="email" required><br>
        <label for="pass">Пароль:</label><br>
        <input type="pass" id="pass" name="pass" required><br><br>
        <button type="submit">Войти</button><br><br>
        <a href="#">Забыли пароль?</a>
        <style>
         .register-btn {
             display: block;
             margin-top: 10px;
             color: #fff;
             background-color: #007bff;
             padding: 10px 20px;
             text-align: center;
             text-decoration: none;
             border-radius: 5px;
          }
          .register-btn:hover {
            background-color: #0056b3;
          }
        </style>
        <a href="registration.php" class="register-btn">Зарегистрироваться</a>
    </form>
</div>
</body>
</html>