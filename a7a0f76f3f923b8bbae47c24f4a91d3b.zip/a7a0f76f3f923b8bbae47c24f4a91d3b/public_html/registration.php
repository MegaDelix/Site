<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, inital-scale=1.0">
<title>Регистрация</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>
<style>
.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

    .header ul {
        display: flex;
        list-style: none;
        margin: 10px 10px 10px 0;
        padding: 0;
    }

    .header li {
        margin-left: 10px;
    }

    .header nav {
        margin-left: auto;
    }
    .header a {
        color: black;
        font-size: 15px;
        font-weight: bold;
        text-decoration: none;
    }

    .header li:nth-child(2) a {
        background-color: #66B2FF;
        color: white;
        padding: 5px 15px;
        border-radius: 10px;
        text-decoration: none;
    }

    .header li:nth-child(3) a {
        color: #66B2FF;
        padding: 5px 15px;
        border: 2px solid #66B2FF;
        border-radius: 10px;
        text-decoration: none;
    }
</style>
<?php require "blocks/header.php" ?>
<div class="form_container">
  <form method="post" action="check.php">
    <label for="login">Введите логин:</label><br>
    <input type="text" id="login" name="login" placeholder="Введите логин" required><br>
    <label for="email">Введите почту:</label><br>
    <input type="email" id="email" name="email" placeholder="Введите почту" required><br>
    <label for="pass">Придумайте пароль:</label><br>
    <input type="pass" id="pass" name="pass" placeholder="Придумайте пароль" required><br><br>
    <button class="btn btn-success" type="submit">Зарегистрироваться</button><br><br>
    <br><a>Есть аккаунт?</a>
        <style>
         .login-btn {
             display: block;
             margin-top: 10px;
             color: #fff;
             background-color: #007bff;
             padding: 10px 20px;
             text-align: center;
             text-decoration: none;
             border-radius: 5px;
          }
          .login-btn:hover {
            background-color: #0056b3;
          }
        </style>
        <a href="login.php" class="login-btn">Войти</a>
  </form>
</div>
</body>
</html>