<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Main Page</title>
<style>
    body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    }
    .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: #f0f0f0;
    padding: 10px 20px;
    }
    .header ul {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
    }
    .header li {
    margin-left: 10px;
    }
    .header nav {
    margin-left: auto;
    }
    .header a {
    color: black;
    font-size: 24px;
    font-weight: bold;
    text-decoration: none;
    }
    .header li:nth-child(2) a {
    background-color: #66B2FF;
    color: white;
    padding: 10px;
    border-radius: 10px;
    text-decoration: none;
    }
    .header li:nth-child(3) a {
    color: #66B2FF;
    padding: 10px;
    border: 2px solid #66B2FF;
    border-radius: 10px;
    text-decoration: none;
    }
    .content {
    text-align: center;
    }
    .buttons {
    margin-top: 20px;
    }
    .blue-button {
    background-color: #66B2FF;
    color: white;
    padding: 10px 20px;
    border-radius: 20px;
    border: none;
    cursor: pointer;
    }
    .blue-outline-button {
    color: #66B2FF;
    padding: 10px 20px;
    border: 2px solid #66B2FF;
    border-radius: 20px;
    background-color: transparent;
    cursor: pointer;
    }
</style>
</head>
<body>
<?php require "blocks/header.php" ?>
<div class="content">
    <p style="font-family: 'Times New Roman'; font-weight: bold; text-align: center; font-size: 30px;">
        Добро пожаловать! <br>Давайте приступим к работе
    </p>
    <?php
            if($_COOKIE['user'] == ''):
          ?>
             <li> войдите,чтобы получать новости среди первых!</li>
             <div class="buttons">
               <button class="blue-button" onclick="window.location.href='login.php'">Вход</button>
               <button class="blue-outline-button" onclick="window.location.href='registration.php'">Регистрация</button>
             </div>
             <br><img src="./img/n2.png" alt="ddd" width="1600" height="640" />
          <?php else: ?>
          <img src="./img/n.jpg" alt="ddd" width="1000" height="480" />
          <br><br><a href="blog.php" style="padding: 10px 20px; background-color: #ff6600;
          color: #fff; text-decoration: none; border-radius: 5px;">Свежие новости для вас!
          </a>
          <?php endif;?>

</div>
</body>
<?php require "blocks/footer.php" ?>
</html>