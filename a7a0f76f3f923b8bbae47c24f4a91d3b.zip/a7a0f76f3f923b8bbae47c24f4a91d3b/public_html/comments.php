<?php
header('Content-Type: text/html; charset=UTF-8');
$mysqli = new mysqli('localhost', 'c95301sd_users', 'Pass1234', 'c95301sd_users');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment']) && isset($_POST['blog_id'])) {
    $login = $_COOKIE['user'];
    $date_time = date('Y-m-d H:i:s');
    $content = $mysqli->real_escape_string($_POST['comment']);
    $blog_id = $_POST['blog_id'];

    $user_id_query = "SELECT id FROM users WHERE login = '$login'";
    $result = $mysqli->query($user_id_query);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['id'];
    
        $query = "INSERT INTO comments (user_id, blog_id, date_time, content) VALUES ('$user_id', '$blog_id', '$date_time', '$content')";
        
        if ($mysqli->query($query) === TRUE) {
            header('Location: ' . $_SERVER['HTTP_REFERER']);
            exit;
        } else {
            echo "Ошибка: " . $query . " " . $mysqli->error;
        }
    } else {
        echo "Пользователь не найден.";
    }
}
?>