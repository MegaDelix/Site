<?php
   $login = filter_var(trim($_POST['login']),
   FILTER_SANITIZE_STRING);
   $email = filter_var(trim($_POST['email']),
   FILTER_SANITIZE_STRING);
   $pass = filter_var(trim($_POST['pass']),
   FILTER_SANITIZE_STRING);

   if(mb_strlen($login) < 3 || mb_strlen($login) > 90) {
      echo "Недопустимая длина логина";
      exit();
   } else if(empty($email)) {
      echo "Почта обязательна";
      exit();
   } else if(mb_strlen($pass) < 8 || mb_strlen($pass) > 15) {
      echo "Пароль должен быть длиной не менее 8 символов и не более 15 символов";
      exit();
   }

   $pass = md5($pass."nje4kqb678");

   $mysql = new mysqli('localhost', 'c95301sd_users', 'Pass1234', 'c95301sd_users');
   $mysql->query("INSERT INTO `users` (`login`, `pass`, `email`)
   VALUES('$login', '$pass', '$email')");

   $mysql->close();

   header('Location: /login.php');
?>