<?php
    $email = filter_var(trim($_POST['email']),
    FILTER_SANITIZE_STRING);
    $pass = filter_var(trim($_POST['pass']),
    FILTER_SANITIZE_STRING);

    $pass = md5($pass."nje4kqb678");
   
    $mysql = new mysqli('localhost', 'c95301sd_users', 'Pass1234', 'c95301sd_users');
    $result = $mysql->query("SELECT * FROM `users` WHERE `email` = '$email' AND `pass` = '$pass'");
    $user = $result->fetch_assoc();
    if(count($user) == 0) {
        echo "Неверный логин или пароль!";
        exit();
    }

    setcookie('user', $user['login'], time() + 3600 * 24 * 30, "/");

    $mysql->close(); 

    header('Location: blog.php');   
?>