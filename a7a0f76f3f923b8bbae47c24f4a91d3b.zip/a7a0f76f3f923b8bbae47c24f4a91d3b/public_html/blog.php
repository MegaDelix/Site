<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, inital-scale=1.0">
    <link rel="stylesheet" href="css/Вёрстка%20списка%20элементов.css">
    <title>ТЗ</title>
    <style>
        .favorite-container {
            background-color: #ccc;
            border-radius: 10px;
            padding: 5px 10px;
            display: inline-block;
        }
        .favorite {
            cursor: pointer;
        }
        .favorite:hover .star {
            color: yellow;
        }
        .favorite.active .star {
            color: yellow;
        }
    </style>
</head>
<body>
    <?php require "blocks/header.php" ?>

    <ul class="news__list">
        <?php
        $mysqli = new mysqli('localhost', 'c95301sd_users', 'Pass1234', 'c95301sd_users');

        $result = $mysqli->query("SELECT id, title, date_time, image_name, content FROM news");
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<li class="news__list-item">';
                echo '<div class="image__wrapper">';
                echo '<img src="img/' . $row['image_name'] . '.png" alt="ddd">';
                echo '</div>';
                echo '<div class="news__content">';
                echo '<div class="news__card">';
                echo '<div class="news__descr">';
                echo '<a href="news' . $row['id'] . '.php" class="news__link">';
                echo '<span class="news__date">' . date('d.m.y ', strtotime($row['date_time'])) . '</span>';
                echo $row['title'];
                echo '</a>';
                echo '<p>' . $row['content'] . '</p><br>';
                echo '<div class="favorite-container"><span class="favorite" onclick="toggleFavorite(this)"><span class="star">☆</span> Добавить в избранное</span></div>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
                echo '</li>';
            }
        } else {
            echo 'No data found';
        }

        $mysqli->close();
        ?>
    </ul>
    <?php require "blocks/blog_pagination.php" ?>

    <script>
        function toggleFavorite(element) {
            element.classList.toggle('active');
            if (element.innerHTML === '<span class="star">☆</span> Добавить в избранное') {
                element.innerHTML = '<span class="star">★</span> Удалить из избранного';
            } else {
                element.innerHTML = '<span class="star">☆</span> Добавить в избранное';
            }
        }
    </script>

    <?php require "blocks/footer.php" ?>
</body>
</html>