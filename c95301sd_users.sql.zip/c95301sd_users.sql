-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Апр 11 2024 г., 17:57
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `c95301sd_users`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--
-- Создание: Апр 11 2024 г., 11:26
-- Последнее обновление: Апр 10 2024 г., 11:38
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int NOT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `content` text,
  `blog_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `date_time`, `content`, `blog_id`) VALUES
(4, 14, '2024-03-06 12:02:23', 'я за медведя', 3),
(5, 15, '2024-03-16 07:52:23', 'Бей своих, чтобы чужие боялись', 3),
(6, 16, '2024-04-06 17:12:47', 'Больше мяса', 3),
(16, 13, '2024-04-09 10:40:43', 'Проверка блока комментариев', 3),
(17, 13, '2024-04-10 13:15:19', 'Это сообщение не должно быть в блоке 3', 2),
(20, 13, '2024-04-10 14:38:03', 'Вот это да!', 2),
(21, 13, '2024-04-10 14:38:29', 'Комментарии работают исправно! :)', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--
-- Создание: Апр 11 2024 г., 11:11
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int NOT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `image_name`, `date_time`, `title`, `content`) VALUES
(1, '1', '2024-02-06 05:21:34', 'Панда съела котёнка', 'Ужасный случай произошел в зоопарке, где панда атаковала и съела милого котенка. Согласно охранникам, панда, которую зовут Маньчжан, неожиданно напала на маленького котенка, который проник в ее вольер. Несмотря на попытки охранников спасти бедного котенка, панда была неудержима и съела его за считанные секунды. Инцидент вызвал шок и возмущение у посетителей зоопарка, которые требуют строже контролировать животных, чтобы такие ужасные ситуации больше не повторялись. Уважаемые посетители, будьте осторожны и не подпускайте своих домашних животных к диких животных в зоопарке.'),
(2, '2', '2024-02-16 03:01:05', 'Кошка поцарапала детёныша панды', 'В зоопарке произошел необычный случай: кошка поцарапала детеныша панды. Инцидент произошел, когда один из посетителей заметил, что маленький панденок вышел из своего вольера и оказался рядом с кошкой.\r\nПосетитель успел сделать несколько снимков, на которых видно, как кошка легонько царапает панденка. Сотрудники зоопарка незамедлительно отреагировали на происшествие и вернули детеныша в безопасное место.'),
(3, '3', '2024-03-06 10:54:02', 'Медведь в шоке от происходящего', 'Никогда в жизни Медведь по имени Егор, не видел такого не реалистичного действия. Уже не возможно выяснить, кто бросил первый камень в этот театр абсурда. То ли Панда по имени Саша решила изменить своему рациону и попробовать на зуб котенка. То ли Кот Антон, решил напасть на маленького детёныша панды Максима.');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Апр 08 2024 г., 10:54
-- Последнее обновление: Апр 08 2024 г., 12:58
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `login` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `pass`) VALUES
(13, 'Константин', 'demomail@mail.ru', '949245e45eba4a07fd069c351792f74a'),
(14, 'Степан', 'stepan@mail.ru', '949245e45eba4a07fd069c351792f74a'),
(15, 'Грозный', 'grozniy@mail.ru', '949245e45eba4a07fd069c351792f74a'),
(16, 'Пудж', 'pudj@mail.ru', '949245e45eba4a07fd069c351792f74a');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_blog_id` (`blog_id`);

--
-- Индексы таблицы `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_blog_id` FOREIGN KEY (`blog_id`) REFERENCES `news` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
